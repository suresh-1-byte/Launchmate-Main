import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    domains: ["adzuna.com", "api.adzuna.com", "lh3.googleusercontent.com"],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
    ],
  },
};

export default nextConfig;
