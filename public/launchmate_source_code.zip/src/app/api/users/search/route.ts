import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import { success, error } from "@/lib/api";

export async function GET(request: NextRequest) {
    try {
        const authUser = await getUserFromRequest();
        if (!authUser) return error("Unauthorized", 401);

        const { searchParams } = new URL(request.url);
        const query = searchParams.get("q") || "";

        const users = await prisma.user.findMany({
            where: {
                id: { not: authUser.userId },
                OR: [
                    { name: { contains: query } },
                    { skills: { contains: query } },
                    { email: { contains: query } },
                ],
            },
            select: {
                id: true,
                name: true,
                email: true,
                skills: true,
                bio: true,
                avatar: true,
                _count: {
                    select: {
                        sentConnections: { where: { status: "accepted" } },
                        receivedConnections: { where: { status: "accepted" } },
                    },
                },
            },
            take: 20,
        });

        const formattedUsers = users.map((u) => ({
            ...u,
            skills: u.skills ? (u.skills as unknown as string).split(",").map((s: string) => s.trim()) : [],
        }));

        return success(formattedUsers);
    } catch (err) {
        console.error("Users search error:", err);
        return error("Internal server error", 500);
    }
}
