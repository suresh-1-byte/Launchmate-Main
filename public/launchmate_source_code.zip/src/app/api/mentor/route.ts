import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextRequest } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { success, error } from "@/lib/api";

function buildMentorPrompt(skills: string, targetRole: string, experience: string, question: string): string {
    return `You are LaunchMate AI Mentor — an intelligent, versatile, and highly capable AI assistant specializing in career guidance, software development, and professional growth.

User Context (Use this to tailor your answer if relevant):
- Current Skills: ${skills || "Not specified"}
- Target Role: ${targetRole || "Not specified"}
- Experience Level: ${experience || "Fresher"}

Instruction:
Answer the user's question below completely and intelligently, similar to ChatGPT. While your primary identity is a Career Strategist, you should provide detailed and helpful answers to ALL types of queries. 

If the user asks for a roadmap, specific tutorials, code examples, or general life advice, provide it in a polished, professional, and Markdown-formatted response.

User Question: "${question}"`;
}

export async function POST(req: NextRequest) {
    try {
        const authUser = await getUserFromRequest();
        if (!authUser) return error("Unauthorized", 401);

        const body = await req.json();
        const { message, question, skills, targetRole, experience } = body;

        // Support both 'message' (from user snippet) and 'question' (from current frontend)
        const userQuestion = question || message;

        if (!userQuestion) {
            return error("Please provide a question", 400);
        }

        if (!process.env.GEMINI_API_KEY) {
            return error("Gemini API key missing in .env", 500);
        }

        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash",
        });

        const prompt = buildMentorPrompt(
            skills || "",
            targetRole || "",
            experience || "fresher",
            userQuestion
        );

        try {
            const result = await model.generateContent(prompt);
            const response = await result.response;
            const text = response.text();

            // Maintain compatibility with existing frontend expectations
            return success({ response: text });
        } catch (apiErr: any) {
            console.error("Gemini API Error details:", apiErr.message);
            let friendlyError = "AI mentor failed to respond";

            if (apiErr.message.includes("API key not valid")) {
                friendlyError = "Invalid Gemini API Key. Please verify your GEMINI_API_KEY in the .env file.";
            } else if (apiErr.message.toLowerCase().includes("quota")) {
                friendlyError = "API Quota exceeded. Please try again later.";
            }

            return error(friendlyError, 500);
        }

    } catch (err) {
        console.error("AI ERROR:", err);
        return error("AI mentor failed to respond", 500);
    }
}
