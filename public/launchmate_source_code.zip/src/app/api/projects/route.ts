import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import { success, error } from "@/lib/api";

export async function POST(request: NextRequest) {
    try {
        const authUser = await getUserFromRequest();
        if (!authUser) return error("Unauthorized", 401);

        const body = await request.json();
        const { title, description, githubLink } = body;

        if (!title || !description) {
            return error("Title and description are required", 400);
        }

        const project = await prisma.project.create({
            data: {
                userId: authUser.userId,
                title,
                description,
                githubLink: githubLink || null,
            },
        });

        return success(project, 201);
    } catch (err) {
        console.error("Project POST error:", err);
        return error("Internal server error", 500);
    }
}

export async function GET(request: NextRequest) {
    try {
        const authUser = await getUserFromRequest();
        if (!authUser) return error("Unauthorized", 401);

        const { searchParams } = new URL(request.url);
        const targetUserId = searchParams.get("userId") || authUser.userId;

        const projects = await prisma.project.findMany({
            where: { userId: targetUserId },
            orderBy: { createdAt: "desc" },
            include: {
                user: { select: { name: true, email: true } },
            },
        });

        return success(projects);
    } catch (err) {
        console.error("Projects GET error:", err);
        return error("Internal server error", 500);
    }
}
