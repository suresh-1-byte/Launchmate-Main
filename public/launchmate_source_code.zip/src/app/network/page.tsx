"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";
import { useAuth } from "@/lib/auth-context";

interface UserResult {
    id: string;
    name: string;
    email: string;
    skills: string[];
    bio: string | null;
    avatar: string | null;
    _count: { sentConnections: number; receivedConnections: number };
}

interface Connection {
    id: string;
    senderId: string;
    receiverId: string;
    status: string;
    sender: { id: string; name: string; email: string; skills: string[]; avatar: string | null };
    receiver: { id: string; name: string; email: string; skills: string[]; avatar: string | null };
}

export default function NetworkPage() {
    const { user } = useAuth();
    const [tab, setTab] = useState<"discover" | "connections" | "pending">("discover");
    const [searchQuery, setSearchQuery] = useState("");
    const [users, setUsers] = useState<UserResult[]>([]);
    const [connections, setConnections] = useState<Connection[]>([]);
    const [loading, setLoading] = useState(false);
    const [connecting, setConnecting] = useState<string | null>(null);
    const [responding, setResponding] = useState<string | null>(null);

    const searchUsers = async (q?: string) => {
        setLoading(true);
        try {
            const res = await fetch(`/api/users/search?q=${encodeURIComponent(q || searchQuery)}`);
            const data = await res.json();
            if (data.success) setUsers(data.data);
        } finally {
            setLoading(false);
        }
    };

    const loadConnections = async () => {
        const res = await fetch("/api/connect");
        const data = await res.json();
        if (data.success) setConnections(data.data);
    };

    useEffect(() => {
        searchUsers("");
        loadConnections();
    }, []);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        searchUsers();
    };

    const sendConnection = async (receiverId: string) => {
        setConnecting(receiverId);
        try {
            await fetch("/api/connect", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ receiverId }),
            });
            await loadConnections();
            await searchUsers(searchQuery);
        } finally {
            setConnecting(null);
        }
    };

    const respondConnection = async (connectionId: string, action: string) => {
        setResponding(connectionId);
        try {
            await fetch("/api/connect/accept", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ connectionId, action }),
            });
            await loadConnections();
        } finally {
            setResponding(null);
        }
    };

    const getConnectionStatus = (userId: string): string | null => {
        const conn = connections.find(
            (c) =>
                (c.senderId === user?.id && c.receiverId === userId) ||
                (c.receiverId === user?.id && c.senderId === userId)
        );
        return conn?.status || null;
    };

    const acceptedConnections = connections.filter((c) => c.status === "accepted");
    const pendingReceived = connections.filter(
        (c) => c.status === "pending" && c.receiverId === user?.id
    );

    const menuItems = [
        {
            key: "connections",
            label: "Connections",
            icon: (
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 12C14.2 12 16 10.2 16 8C16 5.8 14.2 4 12 4C9.8 4 8 5.8 8 8C8 10.2 9.8 12 12 12ZM12 14C9.3 14 4 15.3 4 18V20H20V18C20 15.3 14.7 14 12 14Z" />
                </svg>
            ),
            count: acceptedConnections.length
        },
        {
            key: "pending",
            label: "Invitations",
            icon: (
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20 4H4C2.9 4 2.01 4.9 2.01 6L2 18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4ZM20 8L12 13L4 8V6L12 11L20 6V8Z" />
                </svg>
            ),
            count: pendingReceived.length
        },
        {
            key: "discover",
            label: "Find People",
            icon: (
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M15.5 14H14.71L14.43 13.73C15.41 12.59 16 11.11 16 9.5C16 5.91 13.09 3 9.5 3C5.91 3 3 5.91 3 9.5C3 13.09 5.91 16 9.5 16C11.11 16 12.59 15.41 13.73 14.43L14 14.71V15.5L19 20.5L20.5 19L15.5 14ZM9.5 14C7.01 14 5 11.99 5 9.5C5 7.01 7.01 5 9.5 5C11.99 5 14 7.01 14 9.5C14 11.99 11.99 14 9.5 14Z" />
                </svg>
            ),
            count: null
        },
    ];

    return (
        <ProtectedRoute>
            <Navbar />
            <div className="page-container">
                <div className="page-content max-w-6xl mx-auto">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        {/* Left Sidebar */}
                        <div className="lg:col-span-3">
                            <div className="card sticky top-20 p-2">
                                <h2 className="text-sm font-bold text-gray-900 mb-4 px-3 pt-2">Manage my network</h2>
                                <div className="space-y-1">
                                    {menuItems.map((t) => (
                                        <button
                                            key={t.key}
                                            onClick={() => setTab(t.key as any)}
                                            className={`w-full flex justify-between items-center px-3 py-2.5 text-sm font-semibold rounded-lg transition-colors ${tab === t.key
                                                ? "bg-[#057642]/10 text-[#057642]"
                                                : "text-gray-600 hover:bg-gray-100"
                                                }`}
                                        >
                                            <div className="flex items-center gap-3">
                                                <div className={`${tab === t.key ? "text-[#057642]" : "text-gray-400"}`}>
                                                    {t.icon}
                                                </div>
                                                {t.label}
                                            </div>
                                            {t.count !== null && <span className="text-xs">{t.count}</span>}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Main Content Area */}
                        <div className="lg:col-span-9">
                            <div className="card mb-6">
                                <div className="flex justify-between items-center mb-6">
                                    <h1 className="text-lg font-bold text-gray-900">
                                        {tab === "discover" && "People you may know"}
                                        {tab === "connections" && "Your Connections"}
                                        {tab === "pending" && "Pending Invitations"}
                                    </h1>
                                    {tab === "discover" && (
                                        <form onSubmit={handleSearch} className="relative w-64 lg:w-80">
                                            <input
                                                type="text"
                                                value={searchQuery}
                                                onChange={(e) => setSearchQuery(e.target.value)}
                                                className="w-full text-sm py-2 pl-3 pr-10 border border-gray-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#057642]/20 focus:border-[#057642]"
                                                placeholder="Search names or skills..."
                                            />
                                            <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-[#057642]">
                                                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M15.5 14H14.71L14.43 13.73C15.41 12.59 16 11.11 16 9.5C16 5.91 13.09 3 9.5 3C5.91 3 3 5.91 3 9.5C3 13.09 5.91 16 9.5 16C11.11 16 12.59 15.41 13.73 14.43L14 14.71V15.5L19 20.5L20.5 19L15.5 14ZM9.5 14C7.01 14 5 11.99 5 9.5C5 7.01 7.01 5 9.5 5C11.99 5 14 7.01 14 9.5C14 11.99 11.99 14 9.5 14Z" />
                                                </svg>
                                            </button>
                                        </form>
                                    )}
                                </div>

                                {tab === "discover" && (
                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {loading ? (
                                            <div className="col-span-full flex justify-center py-20">
                                                <div className="w-10 h-10 border-4 border-[#057642]/30 border-t-[#057642] rounded-full animate-spin" />
                                            </div>
                                        ) : users.length > 0 ? (
                                            users.map((u) => {
                                                const status = getConnectionStatus(u.id);
                                                return (
                                                    <div key={u.id} className="border border-[#e0e0e0] rounded-xl overflow-hidden flex flex-col items-center p-5 text-center hover:shadow-md transition-all duration-300">
                                                        <div className="w-24 h-24 rounded-full bg-[#057642] border-4 border-white flex items-center justify-center text-white text-3xl font-bold mb-4 shadow-sm">
                                                            {u.name.charAt(0).toUpperCase()}
                                                        </div>
                                                        <h3 className="text-base font-bold text-gray-900 line-clamp-1">{u.name}</h3>
                                                        <p className="text-sm text-gray-500 mb-3 line-clamp-2 h-10">{u.bio || "Career seeker at LaunchMate"}</p>
                                                        <div className="text-xs text-gray-400 font-medium mb-5">{u._count.sentConnections + u._count.receivedConnections} connections</div>

                                                        <div className="mt-auto w-full">
                                                            {status === "accepted" ? (
                                                                <button className="w-full text-sm font-bold text-gray-500 border border-gray-500 rounded-full py-2 hover:bg-gray-50 transition-all">Message</button>
                                                            ) : status === "pending" ? (
                                                                <button className="w-full text-sm font-bold text-gray-500 border border-gray-400 rounded-full py-2 bg-gray-50 cursor-default">Invited</button>
                                                            ) : (
                                                                <button
                                                                    onClick={() => sendConnection(u.id)}
                                                                    disabled={connecting === u.id}
                                                                    className="w-full text-sm font-bold text-[#057642] border border-[#057642] rounded-full py-2 hover:bg-[#057642] hover:text-white transition-all duration-200 disabled:opacity-50"
                                                                >
                                                                    {connecting === u.id ? "Sending..." : "Connect"}
                                                                </button>
                                                            )}
                                                        </div>
                                                    </div>
                                                );
                                            })
                                        ) : (
                                            <div className="col-span-full text-center py-24 text-gray-400">
                                                <svg className="w-16 h-16 mx-auto mb-4 opacity-20" viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M12 12C14.2 12 16 10.2 16 8C16 5.8 14.2 4 12 4C9.8 4 8 5.8 8 8C8 10.2 9.8 12 12 12ZM12 14C9.3 14 4 15.3 4 18V20H20V18C20 15.3 14.7 14 12 14Z" />
                                                </svg>
                                                <p className="text-sm font-semibold">No results found.</p>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {tab === "connections" && (
                                    <div className="space-y-4">
                                        {acceptedConnections.length > 0 ? (
                                            acceptedConnections.map((conn) => {
                                                const other = conn.senderId === user?.id ? conn.receiver : conn.sender;
                                                return (
                                                    <div key={conn.id} className="flex items-center gap-4 py-4 border-b border-[#f0f0f0] last:border-0 px-4 hover:bg-gray-50 transition-all rounded-lg group">
                                                        <div className="w-14 h-14 rounded-full bg-[#057642] flex items-center justify-center text-white text-xl font-bold shadow-sm">
                                                            {other.name.charAt(0).toUpperCase()}
                                                        </div>
                                                        <div className="flex-1">
                                                            <h3 className="text-base font-bold text-gray-900 group-hover:underline cursor-pointer">{other.name}</h3>
                                                            <p className="text-sm text-gray-500">{other.email}</p>
                                                        </div>
                                                        <button className="text-sm font-bold text-[#057642] border border-[#057642] rounded-full px-6 py-2 hover:bg-[#057642] hover:text-white transition-all">Message</button>
                                                    </div>
                                                );
                                            })
                                        ) : (
                                            <div className="text-center py-24 text-gray-400">
                                                <p className="text-sm font-semibold">No connections yet.</p>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {tab === "pending" && (
                                    <div className="space-y-4">
                                        {pendingReceived.length > 0 ? (
                                            pendingReceived.map((conn) => (
                                                <div key={conn.id} className="flex items-center gap-4 py-4 border-b border-[#f0f0f0] last:border-0 px-4 hover:bg-gray-50 transition-all rounded-lg">
                                                    <div className="w-14 h-14 rounded-full bg-orange-600 flex items-center justify-center text-white text-xl font-bold shadow-sm">
                                                        {conn.sender.name.charAt(0).toUpperCase()}
                                                    </div>
                                                    <div className="flex-1">
                                                        <h3 className="text-base font-bold text-gray-900">{conn.sender.name}</h3>
                                                        <p className="text-sm text-gray-500">invites you to connect</p>
                                                        <p className="text-xs text-gray-400 mt-1 line-clamp-1">{conn.sender.email}</p>
                                                    </div>
                                                    <div className="flex gap-3">
                                                        <button
                                                            onClick={() => respondConnection(conn.id, "accepted")}
                                                            disabled={responding === conn.id}
                                                            className="text-sm font-bold text-[#057642] border border-[#057642] rounded-full px-6 py-2 hover:bg-[#057642] hover:text-white transition-all disabled:opacity-50"
                                                        >
                                                            Accept
                                                        </button>
                                                        <button
                                                            onClick={() => respondConnection(conn.id, "rejected")}
                                                            disabled={responding === conn.id}
                                                            className="text-sm font-bold text-gray-500 px-6 py-2 hover:bg-gray-100 rounded-full transition-all disabled:opacity-50"
                                                        >
                                                            Ignore
                                                        </button>
                                                    </div>
                                                </div>
                                            ))
                                        ) : (
                                            <div className="text-center py-24 text-gray-400">
                                                <p className="text-sm font-semibold">No pending invitations.</p>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </ProtectedRoute>
    );
}
