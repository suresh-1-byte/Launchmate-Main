"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";

interface Course {
    id: string;
    title: string;
    description: string;
    level: string;
    duration: string;
    category: string;
    _count: { enrollments: number };
}

interface Enrollment {
    id: string;
    courseId: string;
    progress: number;
    course: Course;
}

const CATEGORIES = [
    { value: "all", label: "All Topics" },
    { value: "web-development", label: "Web Development" },
    { value: "data-science", label: "Data Science" },
    { value: "dsa", label: "Algorithms" },
    { value: "cloud", label: "Cloud Computing" },
    { value: "mobile", label: "Mobile Dev" },
];

const levelColors: Record<string, string> = {
    beginner: "text-green-600 bg-green-50",
    intermediate: "text-blue-600 bg-blue-50",
    advanced: "text-purple-600 bg-purple-50",
};

export default function LearningPage() {
    const [courses, setCourses] = useState<Course[]>([]);
    const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
    const [category, setCategory] = useState("all");
    const [level, setLevel] = useState("all");
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(true);
    const [enrolling, setEnrolling] = useState<string | null>(null);
    const [tab, setTab] = useState<"browse" | "enrolled">("browse");

    const loadCourses = async () => {
        const params = new URLSearchParams();
        if (category !== "all") params.set("category", category);
        if (level !== "all") params.set("level", level);
        if (search) params.set("search", search);

        const res = await fetch(`/api/courses?${params}`);
        const data = await res.json();
        if (data.success) setCourses(data.data);
    };

    const loadEnrollments = async () => {
        const res = await fetch("/api/courses/enroll");
        const data = await res.json();
        if (data.success) setEnrollments(data.data);
    };

    useEffect(() => {
        Promise.all([loadCourses(), loadEnrollments()]).finally(() => setLoading(false));
    }, []);

    useEffect(() => {
        loadCourses();
    }, [category, level]);

    const handleEnroll = async (courseId: string) => {
        setEnrolling(courseId);
        try {
            const res = await fetch("/api/courses/enroll", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ courseId }),
            });
            const data = await res.json();
            if (data.success) {
                await loadEnrollments();
            }
        } finally {
            setEnrolling(null);
        }
    };

    const handleProgress = async (enrollmentId: string, progress: number) => {
        const newProgress = Math.min(100, progress + 10);
        await fetch("/api/courses/progress", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ enrollmentId, progress: newProgress }),
        });
        await loadEnrollments();
    };

    const isEnrolled = (courseId: string) => enrollments.some((e) => e.courseId === courseId);
    const getEnrollment = (courseId: string) => enrollments.find((e) => e.courseId === courseId);

    const menuItems = [
        {
            key: "browse",
            label: "Browse Courses",
            icon: (
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M15.5 14H14.71L14.43 13.73C15.41 12.59 16 11.11 16 9.5C16 5.91 13.09 3 9.5 3C5.91 3 3 5.91 3 9.5C3 13.09 5.91 16 9.5 16C11.11 16 12.59 15.41 13.73 14.43L14 14.71V15.5L19 20.5L20.5 19L15.5 14ZM9.5 14C7.01 14 5 11.99 5 9.5C5 7.01 7.01 5 9.5 5C11.99 5 14 7.01 14 9.5C14 11.99 11.99 14 9.5 14Z" />
                </svg>
            )
        },
        {
            key: "enrolled",
            label: "My Courses",
            icon: (
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 3L1 9L12 15L21 10.09V17H23V9L12 3ZM12 17L3 12.09V14.09L12 19L21 14.09V12.09L12 17Z" />
                </svg>
            ),
            count: enrollments.length
        },
    ];

    return (
        <ProtectedRoute>
            <Navbar />
            <div className="page-container">
                <div className="page-content max-w-6xl mx-auto">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        {/* Sidebar */}
                        <div className="lg:col-span-3">
                            <div className="card sticky top-20 p-2">
                                <h2 className="text-sm font-bold text-gray-900 mb-4 px-3 pt-2">Learning Dashboard</h2>
                                <div className="space-y-1">
                                    {menuItems.map((item) => (
                                        <button
                                            key={item.key}
                                            onClick={() => setTab(item.key as any)}
                                            className={`w-full flex justify-between items-center px-3 py-2.5 text-sm font-semibold rounded-lg transition-colors ${tab === item.key ? "bg-[#057642]/10 text-[#057642]" : "text-gray-600 hover:bg-gray-100"}`}
                                        >
                                            <div className="flex items-center gap-3">
                                                <div className={`${tab === item.key ? "text-[#057642]" : "text-gray-400"}`}>
                                                    {item.icon}
                                                </div>
                                                {item.label}
                                            </div>
                                            {item.count !== undefined && item.count !== null && <span className="text-xs">{item.count}</span>}
                                        </button>
                                    ))}
                                </div>

                                <div className="mt-8 border-t border-[#e0e0e0] pt-4 px-3 pb-2">
                                    <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Categories</h3>
                                    <div className="space-y-1">
                                        {CATEGORIES.map((cat) => (
                                            <button
                                                key={cat.value}
                                                onClick={() => { setCategory(cat.value); setTab("browse"); }}
                                                className={`w-full text-left px-2 py-1.5 text-xs font-semibold rounded transition-colors ${category === cat.value ? "text-[#057642] bg-green-50/50" : "text-gray-500 hover:text-gray-900 hover:bg-gray-50"}`}
                                            >
                                                {cat.label}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Content Area */}
                        <div className="lg:col-span-9">
                            <div className="card mb-6 p-6">
                                <div className="flex justify-between items-center mb-8">
                                    <h1 className="text-xl font-bold text-gray-900">
                                        {tab === "browse" ? "Explore Courses" : "Your Learning Path"}
                                    </h1>
                                    {tab === "browse" && (
                                        <div className="flex gap-2">
                                            <div className="relative">
                                                <input
                                                    type="text"
                                                    value={search}
                                                    onChange={(e) => setSearch(e.target.value)}
                                                    className="text-sm py-2 px-4 pl-10 border border-gray-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#057642]/20 focus:border-[#057642] w-64"
                                                    placeholder="Search skills..."
                                                />
                                                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                                                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                                                        <path d="M15.5 14H14.71L14.43 13.73C15.41 12.59 16 11.11 16 9.5C16 5.91 13.09 3 9.5 3C5.91 3 3 5.91 3 9.5C3 13.09 5.91 16 9.5 16C11.11 16 12.59 15.41 13.73 14.43L14 14.71V15.5L19 20.5L20.5 19L15.5 14ZM9.5 14C7.01 14 5 11.99 5 9.5C5 7.01 7.01 5 9.5 5C11.99 5 14 7.01 14 9.5C14 11.99 11.99 14 9.5 14Z" />
                                                    </svg>
                                                </div>
                                            </div>
                                            <button onClick={loadCourses} className="text-sm font-bold bg-[#057642] text-white px-6 py-2 rounded-lg hover:bg-[#046237] transition-all">Search</button>
                                        </div>
                                    )}
                                </div>

                                {loading ? (
                                    <div className="flex justify-center py-24">
                                        <div className="w-10 h-10 border-4 border-[#057642]/30 border-t-[#057642] rounded-full animate-spin" />
                                    </div>
                                ) : tab === "browse" ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        {courses.map((course) => {
                                            const enrolled = isEnrolled(course.id);
                                            const enrollment = getEnrollment(course.id);
                                            return (
                                                <div key={course.id} className="border border-[#e0e0e0] rounded-xl p-5 hover:shadow-lg transition-all flex flex-col group">
                                                    <div className="flex justify-between items-start mb-4">
                                                        <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${levelColors[course.level] || "text-gray-500 bg-gray-100"}`}>
                                                            {course.level}
                                                        </span>
                                                        <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-bold uppercase">
                                                            <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor">
                                                                <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z" />
                                                            </svg>
                                                            {course.duration}
                                                        </div>
                                                    </div>
                                                    <h3 className="text-base font-bold text-gray-900 mb-2 group-hover:text-[#057642] transition-colors">{course.title}</h3>
                                                    <p className="text-sm text-gray-500 mb-6 line-clamp-3 leading-relaxed flex-1">{course.description}</p>

                                                    <div className="mt-auto pt-5 border-t border-[#f0f0f0]">
                                                        {enrolled && enrollment ? (
                                                            <div className="space-y-4">
                                                                <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wide">
                                                                    <span className="text-gray-400">Current Progress</span>
                                                                    <span className="text-[#057642]">{enrollment.progress}%</span>
                                                                </div>
                                                                <div className="progress-bar">
                                                                    <div className="progress-fill" style={{ width: `${enrollment.progress}%` }} />
                                                                </div>
                                                                <button
                                                                    onClick={() => handleProgress(enrollment.id, enrollment.progress)}
                                                                    className="w-full py-2.5 bg-white border border-[#057642] text-[#057642] text-sm font-bold rounded-full hover:bg-green-50 transition-all font-bold"
                                                                >
                                                                    {enrollment.progress >= 100 ? "Review Content" : "Continue Learning"}
                                                                </button>
                                                            </div>
                                                        ) : (
                                                            <button
                                                                onClick={() => handleEnroll(course.id)}
                                                                disabled={enrolling === course.id}
                                                                className="w-full py-2.5 bg-[#057642] text-white text-sm font-bold rounded-full hover:bg-[#046237] shadow-sm hover:shadow-md transition-all disabled:opacity-50"
                                                            >
                                                                {enrolling === course.id ? "Enrolling..." : "Enroll Now"}
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                ) : (
                                    <div className="space-y-6">
                                        {enrollments.length > 0 ? (
                                            enrollments.map((en) => (
                                                <div key={en.id} className="flex flex-col sm:flex-row gap-5 p-5 border border-[#e0e0e0] rounded-xl hover:shadow-md transition-all group">
                                                    <div className="w-16 h-16 bg-[#057642]/10 rounded-xl flex items-center justify-center text-[#057642] flex-shrink-0">
                                                        <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
                                                            <path d="M12 3L1 9L12 15L21 10.09V17H23V9L12 3ZM12 17L3 12.09V14.09L12 19L21 14.09V12.09L12 17Z" />
                                                        </svg>
                                                    </div>
                                                    <div className="flex-1">
                                                        <h3 className="text-base font-bold text-gray-900 group-hover:text-[#057642] transition-colors">{en.course.title}</h3>
                                                        <div className="flex items-center gap-4 mt-2 mb-4">
                                                            <span className="text-[10px] font-bold text-gray-500 bg-gray-50 border border-gray-200 px-2.5 py-1 rounded-full">{en.course.level}</span>
                                                            <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-bold uppercase">
                                                                <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor">
                                                                    <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z" />
                                                                </svg>
                                                                {en.course.duration}
                                                            </div>
                                                        </div>
                                                        <div className="flex items-center gap-6">
                                                            <div className="flex-1 progress-bar">
                                                                <div className="progress-fill" style={{ width: `${en.progress}%` }} />
                                                            </div>
                                                            <span className="text-sm font-bold text-[#057642]">{en.progress}%</span>
                                                        </div>
                                                    </div>
                                                    <button
                                                        onClick={() => handleProgress(en.id, en.progress)}
                                                        className="sm:self-center px-8 py-2.5 bg-[#057642] text-white text-sm font-bold rounded-full hover:bg-[#046237] shadow-sm transition-all"
                                                    >
                                                        {en.progress >= 100 ? "Watch Again" : "Continue"}
                                                    </button>
                                                </div>
                                            ))
                                        ) : (
                                            <div className="text-center py-24 text-gray-400">
                                                <svg className="w-16 h-16 mx-auto mb-4 opacity-20" viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M12 3L1 9L12 15L21 10.09V17H23V9L12 3ZM12 17L3 12.09V14.09L12 19L21 14.09V12.09L12 17Z" />
                                                </svg>
                                                <p className="text-sm font-semibold">No enrollments yet. Start exploring!</p>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </ProtectedRoute>
    );
}
