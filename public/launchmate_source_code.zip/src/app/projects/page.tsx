"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";

interface Project {
    id: string;
    title: string;
    description: string;
    githubLink: string | null;
    score: number | null;
    createdAt: string;
    user: { name: string; email: string };
}

export default function ProjectsPage() {
    const [projects, setProjects] = useState<Project[]>([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [githubLink, setGithubLink] = useState("");
    const [submitting, setSubmitting] = useState(false);

    const loadProjects = async () => {
        const res = await fetch("/api/projects");
        const data = await res.json();
        if (data.success) setProjects(data.data);
        setLoading(false);
    };

    useEffect(() => {
        loadProjects();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const res = await fetch("/api/projects", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ title, description, githubLink: githubLink || null }),
            });
            const data = await res.json();
            if (data.success) {
                setTitle("");
                setDescription("");
                setGithubLink("");
                setShowForm(false);
                await loadProjects();
            }
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <ProtectedRoute>
            <Navbar />
            <div className="page-container">
                <div className="page-content max-w-6xl mx-auto px-4">
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-10 gap-4">
                        <div>
                            <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight flex items-center gap-3">
                                <div className="p-2 bg-[#057642]/10 rounded-lg text-[#057642]">
                                    <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M22 6C22 4.9 21.1 4 20 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6ZM20 6V18H4V6H20ZM6 10H18V12H6V10ZM6 14H14V16H6V14Z" />
                                    </svg>
                                </div>
                                Portfolio Projects
                            </h1>
                            <p className="text-gray-500 mt-2 text-sm font-medium">Showcase your technical work and build your professional credibility.</p>
                        </div>
                        <button
                            onClick={() => setShowForm(!showForm)}
                            className={`flex items-center gap-2 px-6 py-2.5 rounded-full font-bold text-sm transition-all shadow-md active:scale-95 ${showForm
                                ? "bg-red-50 text-red-600 border border-red-200 hover:bg-red-100"
                                : "bg-[#057642] text-white hover:bg-[#046237]"}`}
                        >
                            {showForm ? (
                                <>
                                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6L6 18M6 6l12 12" /></svg>
                                    Cancel
                                </>
                            ) : (
                                <>
                                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M19 13H13V19H11V13H5V11H11V5H13V11H19V13Z" /></svg>
                                    Add Project
                                </>
                            )}
                        </button>
                    </div>

                    {/* Add Project Form */}
                    {showForm && (
                        <div className="card mb-10 p-8 shadow-xl border border-[#e0e0e0] rounded-2xl animate-slide-up">
                            <h2 className="text-lg font-bold text-gray-900 mb-6 uppercase tracking-wider">Project Specifications</h2>
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Project Name</label>
                                        <input
                                            type="text"
                                            value={title}
                                            onChange={(e) => setTitle(e.target.value)}
                                            className="w-full text-sm py-3 px-4 bg-gray-50 border border-gray-300 rounded-xl focus:ring-4 focus:ring-[#057642]/10 focus:border-[#057642] focus:outline-none transition-all"
                                            placeholder="e.g. Real-time Analytics Dashboard"
                                            required
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">GitHub Repository (URL)</label>
                                        <input
                                            type="url"
                                            value={githubLink}
                                            onChange={(e) => setGithubLink(e.target.value)}
                                            className="w-full text-sm py-3 px-4 bg-gray-50 border border-gray-300 rounded-xl focus:ring-4 focus:ring-[#057642]/10 focus:border-[#057642] focus:outline-none transition-all"
                                            placeholder="https://github.com/username/repo"
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Detailed Description</label>
                                    <textarea
                                        value={description}
                                        onChange={(e) => setDescription(e.target.value)}
                                        className="w-full text-sm py-3 px-4 bg-gray-50 border border-gray-300 rounded-xl focus:ring-4 focus:ring-[#057642]/10 focus:border-[#057642] focus:outline-none transition-all resize-none"
                                        rows={5}
                                        placeholder="Describe the problem solved, stack used, and your key contributions..."
                                        required
                                    />
                                </div>
                                <div className="flex justify-end">
                                    <button
                                        type="submit"
                                        disabled={submitting}
                                        className="px-10 py-3 bg-[#057642] text-white font-bold rounded-xl hover:bg-[#046237] shadow-lg hover:shadow-xl transition-all active:scale-95 disabled:opacity-50"
                                    >
                                        {submitting ? "Publishing..." : "Publish Project"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    )}

                    {/* Projects List */}
                    {loading ? (
                        <div className="flex justify-center py-24">
                            <div className="w-10 h-10 border-4 border-[#057642]/30 border-t-[#057642] rounded-full animate-spin" />
                        </div>
                    ) : projects.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {projects.map((project, i) => (
                                <div
                                    key={project.id}
                                    className="group card p-6 shadow-md border border-[#e0e0e0] rounded-2xl hover:shadow-xl hover:border-[#057642]/30 transition-all duration-300 animate-slide-up flex flex-col"
                                    style={{ animationDelay: `${0.1 * i}s` }}
                                >
                                    <div className="flex items-start justify-between mb-4">
                                        <h3 className="text-lg font-bold text-gray-900 group-hover:text-[#057642] transition-colors">{project.title}</h3>
                                        {project.score && (
                                            <div className="flex items-center gap-1.5 px-3 py-1 bg-green-50 rounded-lg border border-green-100 ring-1 ring-green-600/10">
                                                <span className="text-green-700 text-sm font-extrabold">{project.score}</span>
                                                <span className="text-green-600/40 text-[10px] font-bold uppercase tracking-wider">Rating</span>
                                            </div>
                                        )}
                                    </div>
                                    <p className="text-sm text-gray-500 mb-8 leading-relaxed line-clamp-4 flex-1">{project.description}</p>
                                    <div className="flex items-center justify-between pt-6 border-t border-[#f0f0f0]">
                                        <div className="flex items-center gap-4">
                                            {project.githubLink && (
                                                <a
                                                    href={project.githubLink}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="inline-flex items-center gap-2 text-xs font-bold text-[#057642] bg-[#057642]/5 px-3 py-1.5 rounded-full hover:bg-[#057642] hover:text-white transition-all shadow-sm"
                                                >
                                                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                                        <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
                                                    </svg>
                                                    SOURCE CODE
                                                </a>
                                            )}
                                        </div>
                                        <div className="text-right">
                                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Added on</p>
                                            <p className="text-xs text-gray-900 font-bold">{new Date(project.createdAt).toLocaleDateString()}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="card text-center py-24 flex flex-col items-center justify-center border-dashed border-2 border-gray-300 bg-gray-50 rounded-2xl">
                            <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center text-gray-400 mb-6 group-hover:scale-110 transition-transform">
                                <svg className="w-10 h-10" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M22 6C22 4.9 21.1 4 20 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6ZM20 6V18H4V6H20ZM6 10H18V12H6V10ZM6 14H14V16H6V14Z" />
                                </svg>
                            </div>
                            <h3 className="text-xl font-bold text-gray-900 mb-2">No Projects Published</h3>
                            <p className="text-gray-500 text-sm max-w-xs mb-8">Your portfolio is currently empty. Add your first project to start showing off your skills to potential recruiters.</p>
                            <button
                                onClick={() => setShowForm(true)}
                                className="px-10 py-3 bg-[#057642] text-white font-bold rounded-xl hover:bg-[#046237] shadow-lg hover:shadow-xl transition-all"
                            >
                                Start Your Portfolio
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </ProtectedRoute>
    );
}
